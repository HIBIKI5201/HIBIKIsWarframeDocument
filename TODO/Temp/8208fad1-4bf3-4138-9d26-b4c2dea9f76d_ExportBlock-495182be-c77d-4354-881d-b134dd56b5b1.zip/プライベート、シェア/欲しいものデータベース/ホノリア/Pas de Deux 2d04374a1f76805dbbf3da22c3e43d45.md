# Pas de Deux

条件: WISPでディセンディア全21階層を連続で踏破