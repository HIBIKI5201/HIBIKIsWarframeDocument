# Scrofa Light Trencher

https://wiki.warframe.com/w/Trencher#Scrofa_Light