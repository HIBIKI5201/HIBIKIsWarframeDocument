# Rogue Voidrig (Isolation Vault)

https://wiki.warframe.com/w/Rogue_Voidrig