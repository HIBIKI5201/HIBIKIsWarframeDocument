# Drekar Hellion Eximus

https://wiki.warframe.com/w/Hellion#Drekar