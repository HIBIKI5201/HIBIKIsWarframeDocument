# Scrofa Light Trencher Eximus

https://wiki.warframe.com/w/Trencher#Scrofa_Light