# Gruzzling Eximus

https://wiki.warframe.com/w/Gruzzling