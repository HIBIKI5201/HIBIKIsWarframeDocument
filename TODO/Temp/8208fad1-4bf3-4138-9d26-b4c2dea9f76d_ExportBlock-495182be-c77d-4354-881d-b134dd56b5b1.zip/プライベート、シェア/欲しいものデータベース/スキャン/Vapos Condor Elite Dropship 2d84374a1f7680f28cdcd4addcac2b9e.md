# Vapos Condor Elite Dropship

https://wiki.warframe.com/w/Condor_Dropship#Variants