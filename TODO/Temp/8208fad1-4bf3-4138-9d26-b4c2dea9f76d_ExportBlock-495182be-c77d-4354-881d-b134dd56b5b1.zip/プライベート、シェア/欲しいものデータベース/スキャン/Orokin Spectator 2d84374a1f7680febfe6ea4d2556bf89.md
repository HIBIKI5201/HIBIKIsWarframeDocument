# Orokin Spectator

https://wiki.warframe.com/w/Orokin_Spectator