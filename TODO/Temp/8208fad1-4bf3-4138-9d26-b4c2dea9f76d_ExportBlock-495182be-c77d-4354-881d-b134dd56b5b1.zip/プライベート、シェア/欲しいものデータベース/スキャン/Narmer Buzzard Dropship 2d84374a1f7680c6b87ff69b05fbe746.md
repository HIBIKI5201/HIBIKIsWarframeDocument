# Narmer Buzzard Dropship

https://wiki.warframe.com/w/Narmer_Buzzard_Dropship