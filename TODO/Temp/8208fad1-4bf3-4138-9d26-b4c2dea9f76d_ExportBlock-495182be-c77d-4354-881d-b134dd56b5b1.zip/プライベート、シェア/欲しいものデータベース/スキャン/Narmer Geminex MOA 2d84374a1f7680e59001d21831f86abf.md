# Narmer Geminex MOA

https://wiki.warframe.com/w/Narmer_Geminex_MOA