# Narmer Sapping Osprey

https://wiki.warframe.com/w/Narmer_Sapping_Osprey