# Juno Sap Comba

https://wiki.warframe.com/w/Comba#Sap