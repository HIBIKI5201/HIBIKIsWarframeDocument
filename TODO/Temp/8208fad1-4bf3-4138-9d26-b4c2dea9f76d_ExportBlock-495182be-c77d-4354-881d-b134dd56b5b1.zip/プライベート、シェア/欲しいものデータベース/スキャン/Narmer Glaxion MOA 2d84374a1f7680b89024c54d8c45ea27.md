# Narmer Glaxion MOA

https://wiki.warframe.com/w/Narmer_Glaxion_MOA