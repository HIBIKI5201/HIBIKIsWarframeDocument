# Narmer Condor Dropship

https://wiki.warframe.com/w/Narmer_Condor_Dropship