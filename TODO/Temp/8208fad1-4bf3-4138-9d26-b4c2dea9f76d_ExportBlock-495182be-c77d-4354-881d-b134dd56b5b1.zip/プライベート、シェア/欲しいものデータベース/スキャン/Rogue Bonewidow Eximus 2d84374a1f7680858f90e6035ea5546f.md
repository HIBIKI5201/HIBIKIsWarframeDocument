# Rogue Bonewidow Eximus

https://wiki.warframe.com/w/Rogue_Bonewidow