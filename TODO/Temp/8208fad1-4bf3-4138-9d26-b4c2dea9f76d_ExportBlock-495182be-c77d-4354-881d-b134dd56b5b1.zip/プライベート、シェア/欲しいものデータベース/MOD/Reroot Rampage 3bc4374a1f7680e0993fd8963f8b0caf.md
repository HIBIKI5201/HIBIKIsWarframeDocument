# Reroot Rampage

入手場所: ペリン・ベール